#ifndef CLASS1_H
#define CLASS1_H

class class1{
	public:
		class1(int val);
		int get();
	private:
		int value;

};

#endif
